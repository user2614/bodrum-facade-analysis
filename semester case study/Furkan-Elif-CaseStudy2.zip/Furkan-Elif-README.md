# British Architects Post-20th Century Buildings Dataset

## Research Question
In which geographical areas have British architects concentrated their post-20th century projects, and does this geographical distribution lead to differences in their preferences for building types?

## Description
This dataset was compiled by scraping Wikipedia building pages listed under
the 'Buildings by British Architects' subcategory. Only buildings completed
after the year 1900 are included.

## Data Fields
| Field | Description |
|-------|-------------|
| building_name | Official name of the building |
| architect | Name of the British architect |
| location | City / country of the building |
| year | Year completed or opened |
| building_type | Functional category of the building |
| coordinates | Latitude / longitude |
| wiki_url | Source Wikipedia URL |

## Files
- `dataset.pkl` — Main dataset (Pandas DataFrame)
- `dataDictionary.json` — Variable descriptions
- `metadata.json` — Source, record count, research question
- `requirements.txt` — Python dependencies
- `README.md` — This file

## Scraping Ethics
- Rate limit: 1.5s between each request
- User-Agent header identifies the bot as a student research project
- No aggressive or parallel requests

## Total Records
150 buildings from 7 architects
